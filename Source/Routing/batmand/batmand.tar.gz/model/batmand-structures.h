/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */

/*
 * Copyright (c) 2016 Rochester Institute of Technology
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Nelson Powell <nhp8080@rit.edu>
 *
 * NOTE:
 *
 * Code based on the BATMAND module and modified for BATMAND-0.3.2
 * implementation.  BATMAND was the predecessor for BATMAN and has many
 * similar features.  Plus, modifying the BATMAND module reduces the
 * effort required to write a module from scratch.
 *
 * The BATMAN module is based on the IETF draft found at
 * https://tools.ietf.org/html/draft-openmesh-b-a-t-m-a-n-00 and the
 * BATMAN-0.3.2 code base downloadable from
 * https://www.open-mesh.org/projects/open-mesh/wiki/Download
 *
 *
 */

///
/// \brief Implementation of BATMAND agent and related classes.
///
/// This is the main file of this software because %BATMAND's behavior is
/// implemented here.
///

#ifndef BATMAND_STRUCTURES_H
#define BATMAND_STRUCTURES_H

#include <set>
#include <vector>

#include "batmand-header.h"
#include "ns3/log.h"
#include "ns3/ipv4-address.h"
#include "ns3/nstime.h"
#include "ns3/random-variable-stream.h"

namespace ns3 {
namespace batmand {

/* sliding packet range of received originator messages in sequence numbers
 * (should be a multiple of our word size)
 */
#define TQ_LOCAL_WINDOW_SIZE  64
#define TYPE_OF_WORD          uint64_t

#define TQ_HOP_PENALTY		5


/// \ingroup batmand
/// Batman Protocol format (Packed byte array)
struct bat_packet
{
   uint8_t  version;  /* batman version field */
   uint8_t  flags;    /* 0x80: UNIDIRECTIONAL link, 0x40: DIRECTLINK flag, ... */
   uint8_t  ttl;
   uint8_t  gwflags;  /* flags related to gateway functions: gateway class */
   uint16_t seqno;
   uint16_t gwport;
   uint32_t orig;
   uint32_t prev_sender;
   uint8_t tq;
   uint8_t hna_len;
} __attribute__((packed));

static inline bool
operator == (const bat_packet &a, const bat_packet &b)
{
  return ( a.orig == b.orig &&
           a.seqno == b.seqno &&
           a.ttl == b.ttl );
}

static inline std::ostream&
operator << (std::ostream &os, const bat_packet &pkt)
{
  os << "BATMAN Pkt(OrigAddr=" << pkt.orig
     << ", PrevAddr=" << pkt.prev_sender
     << ", TTL=" << pkt.ttl
     << ", SeqNo=" << pkt.seqno
     << ", Flags=" << pkt.flags
     << ", TQ=" << pkt.tq
     << ", HNALen=" << pkt.hna_len
     << ")";
  return os;
}

/// \ingroup batmand
/// Data structure for a BATMAND enabled interface
struct batman_if
{
   int32_t udp_send_sock;
   int32_t udp_recv_sock;
   int32_t udp_tunnel_sock;
   uint8_t if_num;
   uint8_t if_active;
   int32_t if_index;
   int8_t if_rp_filter_old;
   int8_t if_send_redirects_old;
   pthread_t listen_thread_id;
   Ipv4Address addr;
   Ipv4Address broad;
   Ipv4Address netaddr;
   uint8_t netmask;
   uint8_t wifi_if;
   struct bat_packet out;
};

static inline bool
operator == (const batman_if &a, const batman_if &b)
{
  return ( a.addr == b.addr &&
           a.if_num == b.if_num &&
           a.out.seqno == b.out.seqno);
}

static inline std::ostream&
operator << (std::ostream &os, const batman_if &batmanif)
{
  os << "BATMAN Iface(Addr=" << batmanif.addr
     << ", bcastAddr=" << batmanif.broad
     << ", ifaceNumber=" << (int) batmanif.if_num
     << ")";
  return os;
}

// Forward declare the orig_node
struct orig_node;


struct neigh_node
{
   Ipv4Address addr;
   uint8_t real_packet_count;
   uint8_t *tq_recv;
   uint8_t tq_index;
   uint8_t tq_avg;
   uint8_t last_ttl;
   uint32_t last_valid;            /* when last packet via this neighbor was received */
   uint64_t real_bits;
   struct orig_node *orig_node;
   uint16_t ifnum;                /* replaced the pointer to the BATMAN interface with an IF number */
};

typedef std::map<uint8_t, uint64_t>		BcastWindowMap;
typedef std::map<uint8_t, uint8_t>		BcastSumMap;

typedef std::vector<neigh_node>          NeighborList;   //!< Vector of known neighbors.

/// \ingroup batmand
/// Data structure for orig_list maintaining nodes of mesh
struct orig_node
{
   Ipv4Address orig;
   struct neigh_node *router;
   struct batman_if *batman_if;
   BcastWindowMap bcast_own;
   BcastSumMap bcast_own_sum;
   uint8_t tq_own;
   int tq_asym_penalty;
   uint32_t last_valid;          /* when last packet from this node was received */
   uint8_t  gwflags;             /* flags related to gateway functions: gateway class */
   unsigned char *hna_buff;
   int16_t  hna_buff_len;
   uint16_t last_real_seqno;     /* last and best known squence number */
   uint8_t last_ttl;             /* ttl of last received packet */
   NeighborList neigh_list;
};

static inline bool
operator == (const orig_node &a, const orig_node &b)
{
  return ( a.orig == b.orig &&
           a.batman_if == b.batman_if &&
           a.router == b.router);
}

static inline std::ostream&
operator << (std::ostream &os, const orig_node &neigh)
{
  os << "Neighbor Node(Addr=" << neigh.orig
     << ", ifaceNumber=" << neigh.batman_if->if_num
     << ", TTL=" << (int) neigh.last_ttl
     << ", TQ=" << (int) neigh.tq_own
     << ")";
  return os;
}

struct forw_node                 /* structure for forw_list maintaining packets to be send/forwarded */
{
   ns3::Time send_time;
   uint8_t  own;
   unsigned char *pack_buff;
   uint16_t  pack_buff_len;
   uint32_t direct_link_flags;
   uint8_t num_packets;
   struct batman_if *if_incoming;
};


typedef std::vector<batman_if>           BatmanIfList;   //!< Vector of net devices supporting BATMAN protocol.
typedef std::vector<orig_node>           OriginList;     //!< Vector of known neighbors.
typedef std::vector<forw_node>           ForwardingList; //!< Vector of packets to be forwarded for other nodes.
typedef std::vector<OGMHeader>           MessageList;    //!< Vector of OGM messages to be transmitted

static inline std::ostream& operator<< (std::ostream& os, const MessageList & messages)
{
  os << "[";
  for (std::vector<OGMHeader>::const_iterator messageIter = messages.begin ();
       messageIter != messages.end (); messageIter++)
    {
      messageIter->Print (os);
      if (messageIter + 1 != messages.end ())
        {
          os << ", ";
        }
    }
  os << "]";
  return os;
}


/// \ingroup batmand
/// This class encapsulates all data structures needed for maintaining internal state of an BATMAN node.
class BatmanData
{
  //  friend class Olsr;

protected:
  BatmanIfList    m_batmanif;
  OriginList      m_OriginSet;
  NeighborList    m_neighborSet;
  ForwardingList  m_forwardingSet;

  //LinkSet m_linkSet;    //!< Link Set (\RFC{3626}, section 4.2.1).
  //NeighborSet m_neighborSet;            //!< Neighbor Set (\RFC{3626}, section 4.3.1).
  //TwoHopNeighborSet m_twoHopNeighborSet;        //!< 2-hop Neighbor Set (\RFC{3626}, section 4.3.2).
  //TopologySet m_topologySet;    //!< Topology Set (\RFC{3626}, section 4.4).
  //MprSet m_mprSet;      //!< MPR Set (\RFC{3626}, section 4.3.3).
  //MprSelectorSet m_mprSelectorSet;      //!< MPR Selector Set (\RFC{3626}, section 4.3.4).
  //DuplicateSet m_duplicateSet;  //!< Duplicate Set (\RFC{3626}, section 3.4).
  //IfaceAssocSet m_ifaceAssocSet;        //!< Interface Association Set (\RFC{3626}, section 4.1).
  //AssociationSet m_associationSet; //!<   Association Set (\RFC{3626}, section12.2). Associations obtained from HNA messages generated by other nodes.
  //Associations m_associations;  //!< The node's local Host Network Associations that will be advertised using HNA messages.

public:
  BatmanData ()
  {
    m_uniformRandomVariable = CreateObject<UniformRandomVariable> ();
    m_hopPenalty = TQ_HOP_PENALTY;
  }

  void AddBatmanIface(batman_if iface);

  struct batman_if *FindBatmanIf( Ipv4Address addr );

  struct orig_node *GetOrCreateOrigNode( Ipv4Address addr );

  struct orig_node *FindOrigNode( Ipv4Address addr );

  struct neigh_node *FindNeighborNode( struct orig_node *orig_node, Ipv4Address addr );

  /*
   * Mark a bit in the 64 bit sequence field - a bit vector marking received
   * OGM messages based on sequence number.
   *
   * @param uint64_t      Reference to the sequence bits field
   * @param int32_t       Bit number to be set
   */
  void MarkSequenceBit( uint64_t &seq_bits, int32_t n );

  /*
   * Mark a bit in the 64 bit sequence field - a bit vector marking received
   * OGM messages based on sequence number.
   *
   * @param uint64_t      Reference to the sequence bits field
   * @param int           Number of bits set in the 64 bit word
   */
  int Uint64BitCount( uint64_t &seq_bits );

  /*
   *
   * \return TRUE if the packet is a duplicate
   */
  bool CountRealPackets( OGMHeader &pkt, Ipv4Address neigh, uint8_t ifnum );

  /*
   * \brief This method checks the OGM bit for a given sequence number to determine
   * if the origin node was heard from at a given point in time.  Notice that
   * all arguments are pass by reference as pass by value is slower.
   *
   * REVERSE ENGINEERING NOTES:
   * - I think this is attempting to check the sequence bit from an OGM in the past
   * As CURR > LAST seqno, DIFF goes negative, so this reception could not
   * be a duplicate reception.
   *
   * - If the LAST == CURR, then this is a duplicate and the bit should theoretically
   * be set as we've heard from it.
   *
   * - If LAST > CURR, then we've received an old OGM from someone.
   *
   * \param uint64_t    Local window bit vector
   * \param uint16_t    Last sequence number
   * returns true if corresponding bit in given seq_bits indicates so and curr_seqno is within range of last_seqno
   */
  bool GetHistoricalSequenceBitStatus( uint64_t &seq_bits, int32_t &last_seqno, int32_t &curr_seqno );

  /* receive and process one packet, returns 1 if received seq_num is considered new, 0 if old  */
  bool bit_get_packet( uint64_t &seq_bits, int16_t seq_num_diff, int8_t set_mark );

  /* shift the packet array p by n places. */
  void bit_shift( uint64_t seq_bits, int32_t n );

  struct neigh_node *CreateNeighbor( struct orig_node *orig_node,
                                     struct orig_node *orig_neigh_node,
                                     Ipv4Address neigh,
                                     uint8_t ifnum );

  void ScheduleForwardPacket( struct orig_node *orig_node, struct bat_packet *in,
                              Ipv4Address neigh, uint8_t directlink, int16_t hna_buff_len,
                              struct batman_if *if_incoming, ns3::Time curr_time);

  bool m_aggregationEnabled;
  
  uint8_t m_hopPenalty;
  
    /// Provides uniform random variables.
  Ptr<UniformRandomVariable> m_uniformRandomVariable;
  Time m_ogmInterval;     //!< OGM messages' emission interval.

};

/********** Miscellaneous constants **********/
/// Maximum allowed jitter.
#define BATMAND_MAXJITTER          (m_ogmInterval.GetSeconds () / 4)
/// Maximum allowed sequence number.
#define BATMAND_MAX_SEQ_NUM        65535
/// Random number between [0-BATMAND_MAXJITTER] used to jitter BATMAND packet transmission.
#define JITTER (Seconds (BatmanData::m_uniformRandomVariable->GetValue (0, BATMAND_MAXJITTER)))

/// Maximum number of messages per packet.
#define BATMAND_MAX_MSGS           64
/// Maximum number of hellos per message (4 possible link types * 3 possible nb types).
#define BATMAND_MAX_HELLOS         12
/// Maximum number of addresses advertised on a message.
#define BATMAND_MAX_ADDRS          64

}
}  // namespace ns3, batmand

#endif /* BATMAND_STRUCTURES_H */
