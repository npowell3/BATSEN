/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */

/*
 * Copyright (c) 2016 Rochester Institute of Technology
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Nelson Powell <nhp8080@rit.edu>
 *
 * NOTE:
 *
 * Code based on the BATMAND module and modified for BATMAND-0.3.2
 * implementation.  BATMAND was the predecessor for BATMAN and has many
 * similar features.  Plus, modifying the BATMAND module reduces the
 * effort required to write a module from scratch.
 *
 * The BATMAN module is based on the IETF draft found at
 * https://tools.ietf.org/html/draft-openmesh-b-a-t-m-a-n-00 and the
 * BATMAN-0.3.2 code base downloadable from
 * https://www.open-mesh.org/projects/open-mesh/wiki/Download
 *
 *
 */

///
/// \brief Implementation of BATMAND agent and related classes.
///
/// This is the main file of this software because %BATMAND's behavior is
/// implemented here.
///


#define NS_LOG_APPEND_CONTEXT                                   \
  if (GetObject<Node> ()) { std::clog << "[node " << GetObject<Node> ()->GetId () << "] "; }


#include "batmand-routing-protocol.h"
#include "ns3/socket-factory.h"
#include "ns3/udp-socket-factory.h"
#include "ns3/simulator.h"
#include "ns3/log.h"
#include "ns3/names.h"
#include "ns3/inet-socket-address.h"
#include "ns3/ipv4-routing-protocol.h"
#include "ns3/ipv4-routing-table-entry.h"
#include "ns3/ipv4-route.h"
#include "ns3/boolean.h"
#include "ns3/uinteger.h"
#include "ns3/enum.h"
#include "ns3/trace-source-accessor.h"
#include "ns3/ipv4-header.h"

/********** Useful macros **********/

///
/// \brief Gets the delay between a given time and the current time.
///
/// If given time is previous to the current one, then this macro returns
/// a number close to 0. This is used for scheduling events at a certain moment.
///
#define DELAY(time) (((time) < (Simulator::Now ())) ? Seconds (0.000001) : \
                     (time - Simulator::Now () + Seconds (0.000001)))

///
/// \brief Period at which a node must cite every link and every neighbor.
///
/// We only use this value in order to define BATMAND_NEIGHB_HOLD_TIME.
///
#define BATMAND_REFRESH_INTERVAL   m_state.m_ogmInterval


/********** Holding times **********/
/// Neighbor holding time.
#define BATMAND_NEIGHB_HOLD_TIME   Time (3 * BATMAND_REFRESH_INTERVAL)
/// Top holding time.
#define BATMAND_TOP_HOLD_TIME      Time (3 * m_tcInterval)
/// Dup holding time.
#define BATMAND_DUP_HOLD_TIME      Seconds (30)
/// MID holding time.
#define BATMAND_MID_HOLD_TIME      Time (3 * m_midInterval)
/// HNA holding time.
#define BATMAND_HNA_HOLD_TIME      Time (3 * m_hnaInterval)

/********** Link types **********/
/// Unspecified link type.
#define BATMAND_UNSPEC_LINK        0
/// Asymmetric link type.
#define BATMAND_ASYM_LINK          1
/// Symmetric link type.
#define BATMAND_SYM_LINK           2
/// Lost link type.
#define BATMAND_LOST_LINK          3

/********** Neighbor types **********/
/// Not neighbor type.
#define BATMAND_NOT_NEIGH          0
/// Symmetric neighbor type.
#define BATMAND_SYM_NEIGH          1
/// Asymmetric neighbor type.
#define BATMAND_MPR_NEIGH          2


/********** Willingness **********/
/// Willingness for forwarding packets from other nodes: never.
#define BATMAND_WILL_NEVER         0
/// Willingness for forwarding packets from other nodes: low.
#define BATMAND_WILL_LOW           1
/// Willingness for forwarding packets from other nodes: medium.
#define BATMAND_WILL_DEFAULT       3
/// Willingness for forwarding packets from other nodes: high.
#define BATMAND_WILL_HIGH          6
/// Willingness for forwarding packets from other nodes: always.
#define BATMAND_WILL_ALWAYS        7





#define BATMAND_PORT_NUMBER      4305

namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("BatmanProtocol");

namespace batmand {

/********** BATMAND class **********/

NS_OBJECT_ENSURE_REGISTERED (RoutingProtocol);

TypeId
RoutingProtocol::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::batmand::RoutingProtocol")
    .SetParent<Ipv4RoutingProtocol> ()
    .SetGroupName ("Batmand")
    .AddConstructor<RoutingProtocol> ()
    .AddAttribute ("OGMInterval", "OGM messages emission interval.",
                   TimeValue (Seconds (2)),
                   MakeTimeAccessor (&RoutingProtocol::m_state.m_ogmInterval),
                   MakeTimeChecker ())
    .AddAttribute ("Aggregation", "OGM messages aggregation allowed.",
                   false,
                   MakeTimeAccessor (&RoutingProtocol::m_state.m_aggregationEnabled),
                   MakeTimeChecker ())
    .AddTraceSource ("Rx", "Receive BATMAND packet.",
                     MakeTraceSourceAccessor (&RoutingProtocol::m_rxPacketTrace),
                     "ns3::batmand::RoutingProtocol::PacketTxRxTracedCallback")
    .AddTraceSource ("Tx", "Send BATMAND packet.",
                     MakeTraceSourceAccessor (&RoutingProtocol::m_txPacketTrace),
                     "ns3::batmand::RoutingProtocol::PacketTxRxTracedCallback")
    .AddTraceSource ("RoutingTableChanged", "The BATMAND routing table has changed.",
                     MakeTraceSourceAccessor (&RoutingProtocol::m_routingTableChanged),
                     "ns3::batmand::RoutingProtocol::TableChangeTracedCallback")
  ;
  return tid;
}


RoutingProtocol::RoutingProtocol ()
  : m_routingTableAssociation (0),
  m_ipv4 (0),
  m_ogmTimer (Timer::CANCEL_ON_DESTROY),
  m_queuedMessagesTimer (Timer::CANCEL_ON_DESTROY)
{
  m_state.m_uniformRandomVariable = CreateObject<UniformRandomVariable> ();
  m_hnaRoutingTable = Create<Ipv4StaticRouting> ();
}

RoutingProtocol::~RoutingProtocol ()
{
}

void
RoutingProtocol::SetIpv4 (Ptr<Ipv4> ipv4)
{
  NS_ASSERT (ipv4 != 0);
  NS_ASSERT (m_ipv4 == 0);
  NS_LOG_DEBUG ("Created olsr::RoutingProtocol");
  m_ogmTimer.SetFunction (&RoutingProtocol::OgmTimerExpire, this);
  m_queuedMessagesTimer.SetFunction (&RoutingProtocol::SendQueuedMessages, this);

  m_packetSequenceNumber = BATMAND_MAX_SEQ_NUM;

  m_linkTupleTimerFirstTime = true;

  m_ipv4 = ipv4;

  m_hnaRoutingTable->SetIpv4 (ipv4);
}

void RoutingProtocol::DoDispose ()
{
  m_ipv4 = 0;
  m_hnaRoutingTable = 0;
  m_routingTableAssociation = 0;

  for (std::map< Ptr<Socket>, Ipv4InterfaceAddress >::iterator iter = m_socketAddresses.begin ();
       iter != m_socketAddresses.end (); iter++)
    {
      iter->first->Close ();
    }
  m_socketAddresses.clear ();

  Ipv4RoutingProtocol::DoDispose ();
}

void
RoutingProtocol::PrintRoutingTable (Ptr<OutputStreamWrapper> stream) const
{
  std::ostream* os = stream->GetStream ();

  *os << "Node: " << m_ipv4->GetObject<Node> ()->GetId ()
      << ", Time: " << Now ().As (Time::S)
      << ", Local time: " << GetObject<Node> ()->GetLocalTime ().As (Time::S)
      << ", BATMAN Routing table" << std::endl;

  *os << "Destination\t\tNextHop\t\tInterface\tDistance\n";

  for (std::map<Ipv4Address, RoutingTableEntry>::const_iterator iter = m_table.begin ();
       iter != m_table.end (); iter++)
    {
      *os << iter->first << "\t\t";
      *os << iter->second.nextAddr << "\t\t";
      if (Names::FindName (m_ipv4->GetNetDevice (iter->second.interface)) != "")
        {
          *os << Names::FindName (m_ipv4->GetNetDevice (iter->second.interface)) << "\t\t";
        }
      else
        {
          *os << iter->second.interface << "\t\t";
        }
      *os << iter->second.distance << "\t";
      *os << "\n";
    }

  // Also print the HNA routing table
  if (m_hnaRoutingTable->GetNRoutes () > 0)
    {
      *os << " HNA Routing Table: ";
      m_hnaRoutingTable->PrintRoutingTable (stream);
    }
  else
    {
      *os << " HNA Routing Table: empty" << std::endl;
    }
}

void RoutingProtocol::DoInitialize ()
{
  if (m_mainAddress == Ipv4Address ())
    {
      Ipv4Address loopback ("127.0.0.1");
      for (uint32_t i = 0; i < m_ipv4->GetNInterfaces (); i++)
        {
          // Use primary address, if multiple
          Ipv4Address addr = m_ipv4->GetAddress (i, 0).GetLocal ();
          if (addr != loopback)
            {
              m_mainAddress = addr;
              break;
            }
        }

      NS_ASSERT (m_mainAddress != Ipv4Address ());
    }

  NS_LOG_DEBUG ("Starting BATMAND on node " << m_mainAddress);

  Ipv4Address loopback ("127.0.0.1");

  bool canRunBatman = false;
  for (uint32_t i = 0; i < m_ipv4->GetNInterfaces (); i++)
    {
      Ipv4Address addr = m_ipv4->GetAddress (i, 0).GetLocal ();
      if (addr == loopback)
        {
          continue;
        }

      if (addr != m_mainAddress)
        {
          // Create never expiring interface association tuple entries for our
          // own network interfaces, so that GetMainAddress () works to
          // translate the node's own interface addresses into the main address.
          batman_if iface;
          iface.addr = addr;
          iface.netaddr = m_mainAddress;
          m_state.AddBatmanIface ( iface );
          NS_ASSERT ( GetMainAddress (addr) == m_mainAddress );
        }

      if (m_interfaceExclusions.find (i) != m_interfaceExclusions.end ())
        {
          continue;
        }

      // Create a socket to listen only on this interface
      Ptr<Socket> socket = Socket::CreateSocket (GetObject<Node> (),
                                                 UdpSocketFactory::GetTypeId ());
      socket->SetAllowBroadcast (true);
      InetSocketAddress inetAddr (m_ipv4->GetAddress (i, 0).GetLocal (), BATMAND_PORT_NUMBER);
      socket->SetRecvCallback (MakeCallback (&RoutingProtocol::RecvBatmanOgm,  this));
      if (socket->Bind (inetAddr))
        {
          NS_FATAL_ERROR ("Failed to bind() BATMAND socket");
        }
      socket->BindToNetDevice (m_ipv4->GetNetDevice (i));
      m_socketAddresses[socket] = m_ipv4->GetAddress (i, 0);

      canRunBatman = true;
    }

  if (canRunBatman)
    {
      OgmTimerExpire ();

      NS_LOG_DEBUG ("BATMAND on node " << m_mainAddress << " started");
    }
}

void RoutingProtocol::SetMainInterface (uint32_t interface)
{
  m_mainAddress = m_ipv4->GetAddress (interface, 0).GetLocal ();
}

void RoutingProtocol::SetInterfaceExclusions (std::set<uint32_t> exceptions)
{
  m_interfaceExclusions = exceptions;
}

//
// \brief Processes an incoming %BATMAND packet following the
//        https://tools.ietf.org/html/draft-openmesh-b-a-t-m-a-n-00 specification.
void
RoutingProtocol::RecvBatmanOgm (Ptr<Socket> socket)
{
  bool is_my_addr = false;
  bool is_my_orig = false;
  bool is_broadcast = false;
  bool is_my_oldorig = false;

  uint8_t ifnum = 0;

  struct orig_node *orig_neigh_node = NULL, *orig_node = NULL;

  Ptr<Packet> receivedPacket;
  Address sourceAddress;
  receivedPacket = socket->RecvFrom (sourceAddress);

  InetSocketAddress inetSourceAddr = InetSocketAddress::ConvertFrom (sourceAddress);
  Ipv4Address senderIfaceAddr = inetSourceAddr.GetIpv4 ();
  Ipv4Address receiverIfaceAddr = m_socketAddresses[socket].GetLocal ();
  NS_ASSERT (receiverIfaceAddr != Ipv4Address ());
  NS_LOG_DEBUG ("BATMAND node " << m_mainAddress << " received a BATMAND packet from "
                             << senderIfaceAddr << " to " << receiverIfaceAddr);

  // All routing messages are sent from and to port RT_PORT,
  // so we check it.
  NS_ASSERT (inetSourceAddr.GetPort () == BATMAND_PORT_NUMBER);

  Ptr<Packet> packet = receivedPacket;

  batmand::OGMHeader batmanOgmHeader;
  packet->RemoveHeader (batmanOgmHeader);
  NS_ASSERT (batmanOgmHeader.GetPacketLength () >= batmanOgmHeader.GetSerializedSize ());
  uint32_t sizeLeft = batmanOgmHeader.GetPacketLength () - batmanOgmHeader.GetSerializedSize ();

  /*
   * Perform per-interface evaluation as in BATMAN 0.3.2 source code
   */
  Ptr<Node> node = this.GetObject ( <Node> );
  uint32_t devmax = node.GetDevices ();
  for ( uint32_t device = 0; device < devmax; ++device ) {
     if ( sourceAddress == device.GetAddress () ) is_my_addr = true;
     if ( batmanOgmHeader->GetOriginatorAddress () == device.GetAddress () ) is_my_orig = true;
     if ( sourceAddress == device.GetBroadcast () ) is_broadcast = true;
     if ( batmanOgmHeader->GetForwarderAddress () == device.GetAddress () ) is_my_oldorig = true;
  }

  // Find the batman_if structure for the given incoming device
  batman_if *iface = m_state.FindBatmanIf( receiverIfaceAddr );
  if ( iface == NULL )
     NS_LOG_DEBUG ("iface not in list\n");

  ifnum = iface->if_num;

  // If the source is me - I received my own packet ? - so drop
  // guess it could happen on a broadcast medium like CSMA wired
  if ( is_my_addr )
    return;

  // If the source address is a bcast addr - it's not possible so drop
  if ( is_broadcast )
    return;

  // If the Previous Sender is my address, this is my old OGM forwarded by another node
  if ( is_my_oldorig ) {
    // Get or create an ORIG node entry for the given source
    orig_neigh_node = m_state.GetOrCreateOrigNode( senderIfaceAddr );

    // We had to have received the OGM form a station via one of our Batman enabled
    // interfaces, or we received an unknown/invalid OGM
    if ( iface ) {
      if ( ( batmanOgmHeader->HasDirectLinkFlag() ) &&
           ( receiverIfaceAddr == batmanOgmHeader->GetOriginatorAddress () ) &&
           ( batmanOgmHeader->GetPacketSequenceNumber () - iface->out.seqno + 2 == 0 ) )
      {
        NS_LOG_DEBUG ("count own bcast (is_my_orig): old = " << orig_neigh_node->bcast_own_sum[ifnum]);

        m_state.MarkSequenceBit( orig_neigh_node->bcast_own[ifnum], 0);
        orig_neigh_node->bcast_own_sum[ifnum] = m_state.Uint64BitCount( orig_neigh_node->bcast_own[ifnum] );

        NS_LOG_DEBUG ("new = " << orig_neigh_node->bcast_own_sum[ifnum] << " \n");
      }
      else
        NS_LOG_DEBUG ("\n");
    }
    else
       NS_LOG_DEBUG ("receive iface not found in list\n");

    NS_LOG_DEBUG ("Drop packet " << receivedPacket << ": orig pkt from myself (via neighbor " << sourceAddress << ") \n");
    return;
  }

  if (batmanOgmHeader->GetTQvalue() == 0) {
     m_state.CountRealPackets(batmanOgmHeader, sourceAddress, ifnum);

    NS_LOG_DEBUG("Drop packet: originator packet with tq is 0 \n");
    return;
  }

  if (is_my_oldorig) {
    NS_LOG_DEBUG("Drop packet: ignoring all rebroadcast echos (sender: " << neigh << ") \n");
    return;
  }

  is_duplicate = m_state.CountRealPackets(batmanOgmHeader, sourceAddress, ifnum);

  orig_node =  m_state.GetOrCreateOrigNode( batmanOgmHeader->GetOriginatorAddress() );

  /* if sender is a direct neighbor the sender ip equals originator ip */
  orig_neigh_node = (batmanOgmHeader->GetOriginatorAddress() == sourceAddress) ?
                     orig_node : m_state.GetOrCreateOrigNode(sourceAddress);

  /* drop packet if sender is not a direct neighbor and if we no route towards it */
  if ((batmanOgmHeader->GetOriginatorAddress() != sourceAddress) && (orig_neigh_node->router == NULL)) {
    NS_LOG_DEBUG("Drop packet: OGM via unknown neighbor! \n");
    return;
  }

  is_bidirectional = isBidirectionalNeigh(orig_node, orig_neigh_node, batmanOgmHeader, curr_time, ifnum);

  /* update ranking if it is not a duplicate or has the same seqno and similar ttl as the non-duplicate */
  if ((is_bidirectional) && ((!is_duplicate) ||
       ((orig_node->last_real_seqno == batmanOgmHeader.GetPacketSequenceNumber() ) &&
       (orig_node->last_ttl - 3 <= batmanOgmHeader.GetTtl() ))))
    update_orig(orig_node, batmanOgmHeader, sourceAddress, ifnum, hna_recv_buff, hna_buff_len, is_duplicate, curr_time);

  /* is single hop (direct) neighbour */
  if (batmanOgmHeader->GetOriginatorAddress() == sourceAddress) {

    /* mark direct link on incoming interface */
    m_state.ScheduleForwardPacket(orig_node, batmanOgmHeader, sourceAddress, 1, hna_buff_len, ifnum, curr_time);

    NS_LOG_DEBUG("Forward packet: rebroadcast neighbour packet with direct link flag \n");
    return;
  }

  /* multihop originator */
  if (!is_bidirectional) {
    NS_LOG_DEBUG("Drop packet: not received via bidirectional link\n");
    return;
  }

  if (is_duplicate) {
    NS_LOG_DEBUG("Drop packet: duplicate packet received\n");
    return;
  }

  NS_LOG_DEBUG("Forward packet: rebroadcast originator packet \n");

  m_state.ScheduleForwardPacket(orig_node, batmanOgmHeader, sourceAddress, 0, hna_buff_len, ifnum, curr_time);
}


int RoutingProtocol::isBidirectionalNeigh(struct orig_node *orig_node,
                                          struct orig_node *orig_neigh_node,
                                          OGMHeader &in,
                                          uint32_t recv_time,
                                          uint8_t ifnum)
{

   struct list_head *list_pos;
   struct neigh_node *neigh_node = NULL, *tmp_neigh_node = NULL, *tmpNeighNode = NULL;;
   uint8_t total_count;

   if ( orig_node == orig_neigh_node ) {

      for ( int i = 0; i < orig_node->neigh_list.size(); ++i ) {
        tmpNeighNode = &(orig_node->neigh_list[i]);

        if ( ( tmpNeighNode->addr == orig_neigh_node->orig ) && ( tmpNeighNode->ifnum == ifnum ) )
           neigh_node = tmpNeighNode;
      }

      if ( neigh_node == NULL )
         neigh_node = m_state.CreateNeighbor(orig_node, orig_neigh_node, orig_neigh_node->orig, ifnum);

      neigh_node->last_valid = recv_time;
   }
   else {
      /* find packet count of corresponding one hop neighbor */
      for ( int i = 0; i < orig_neigh_node->neigh_list.size(); ++i ) {
        tmpNeighNode = &(orig_neigh_node->neigh_list[i]);

        if ( ( tmpNeighNode->addr == orig_neigh_node->orig ) && ( tmpNeighNode->ifnum == ifnum ) )
          neigh_node = tmpNeighNode;
      }

      if ( neigh_node == NULL )
         neigh_node = m_state.CreateNeighbor(orig_neigh_node, orig_neigh_node, orig_neigh_node->orig, ifnum);
   }

   orig_node->last_valid = recv_time;

   /* pay attention to not get a value bigger than 100% */
   total_count = ( orig_neigh_node->bcast_own_sum[ifnum] > neigh_node->real_packet_count ) ?
                   neigh_node->real_packet_count : orig_neigh_node->bcast_own_sum[ifnum];

   /* if we have too few packets (too less data) we set tq_own to zero */
   /* if we receive too few packets it is not considered bidirectional */
   if ( ( total_count < minimum_send ) || ( neigh_node->real_packet_count < minimum_recv ) ) {
      orig_neigh_node->tq_own = 0;
   }
   else {
      /* neigh_node->real_packet_count is never zero as we only purge old information when getting new information */
      orig_neigh_node->tq_own = (TQ_MAX_VALUE * total_count) / neigh_node->real_packet_count;
   }

   /* 1 - ((1-x)** 3), normalized to TQ_MAX_VALUE */
   /* this does affect the nearly-symmetric links only a little,
    * but punishes asymmetric links more. */
   /* this will give a value between 0 and TQ_MAX_VALUE */
   orig_neigh_node->tq_asym_penalty = TQ_MAX_VALUE - (TQ_MAX_VALUE *
         (local_win_size - neigh_node->real_packet_count) *
         (local_win_size - neigh_node->real_packet_count) *
         (local_win_size - neigh_node->real_packet_count)) /
         (local_win_size * local_win_size * local_win_size);

   in.tq = ((in.tq * orig_neigh_node->tq_own * orig_neigh_node->tq_asym_penalty) / (TQ_MAX_VALUE *  TQ_MAX_VALUE));

   /*debug_output( 3, "bidirectional: orig = %-15s neigh = %-15s => own_bcast = %2i, real recv = %2i, local tq: %3i, asym_penalty: %3i, total tq: %3i \n",
   orig_str, neigh_str, total_count, neigh_node->real_packet_count, orig_neigh_node->tq_own, orig_neigh_node->tq_asym_penalty, in->tq );*/
   NS_LOG_DEBUG("bidirectional: orig = " << orig_node->orig << " neigh = " << orig_neigh_node->orig << " => own_bcast = " <<
                total_count << ", real recv = " << neigh_node->real_packet_count << ", local tq: " << orig_neigh_node->tq_own <<
                ", asym_penalty: " << orig_neigh_node->tq_asym_penalty << ", total tq: " << in.tq );

   /* if link has the minimum required transmission quality consider it bidirectional */
   return (in.tq >= TQ_TOTAL_BIDRECT_LIMIT);
}



void
RoutingProtocol::QueueMessage (const olsr::OGMHeader &message, Time delay)
{
  m_queuedMessages.push_back (message);
  if (not m_queuedMessagesTimer.IsRunning ())
    {
      m_queuedMessagesTimer.SetDelay (delay);
      m_queuedMessagesTimer.Schedule ();
    }
}

void
RoutingProtocol::SendPacket (Ptr<Packet> packet,
                             const MessageList &containedMessages)
{
  NS_LOG_DEBUG ("BATMAND node " << m_mainAddress << " sending a BATMAND packet");

  // Add a header
  batmand::OGMHeader header;
  header.SetPacketLength (header.GetSerializedSize () + packet->GetSize ());
  header.SetPacketSequenceNumber (GetPacketSequenceNumber ());
  packet->AddHeader (header);

  // Trace it
  m_txPacketTrace (header, containedMessages);

  // Send it
  for (std::map<Ptr<Socket>, Ipv4InterfaceAddress>::const_iterator i =
         m_socketAddresses.begin (); i != m_socketAddresses.end (); i++)
    {
      Ipv4Address bcast = i->second.GetLocal ().GetSubnetDirectedBroadcast (i->second.GetMask ());
      i->first->SendTo (packet, 0, InetSocketAddress (bcast, BATMAND_PORT_NUMBER));
    }
}

void
RoutingProtocol::SendQueuedMessages ()
{
  Ptr<Packet> packet = Create<Packet> ();
  int numMessages = 0;

  NS_LOG_DEBUG ("Olsr node " << m_mainAddress << ": SendQueuedMessages");

  MessageList msglist;

  for (std::vector<olsr::MessageHeader>::const_iterator message = m_queuedMessages.begin ();
       message != m_queuedMessages.end ();
       message++)
    {
      Ptr<Packet> p = Create<Packet> ();
      p->AddHeader (*message);
      packet->AddAtEnd (p);
      msglist.push_back (*message);
      if (++numMessages == BATMAND_MAX_MSGS)
        {
          SendPacket (packet, msglist);
          msglist.clear ();
          // Reset variables for next packet
          numMessages = 0;
          packet = Create<Packet> ();
        }
    }

  if (packet->GetSize ())
    {
      SendPacket (packet, msglist);
    }

  m_queuedMessages.clear ();
}

void
RoutingProtocol::SendOGM ()
{
  NS_LOG_FUNCTION (this);

  olsr::MessageHeader msg;
  Time now = Simulator::Now ();

  msg.SetVTime (BATMAND_NEIGHB_HOLD_TIME);
  msg.SetOriginatorAddress (m_mainAddress);
  msg.SetTimeToLive (1);
  msg.SetHopCount (0);
  msg.SetMessageSequenceNumber (GetMessageSequenceNumber ());
  olsr::MessageHeader::Hello &hello = msg.GetHello ();

  hello.SetHTime (m_state.m_ogmInterval);
  hello.willingness = m_willingness;

  std::vector<olsr::MessageHeader::Hello::LinkMessage>
  &linkMessages = hello.linkMessages;

  const LinkSet &links = m_state.GetLinks ();
  for (LinkSet::const_iterator link_tuple = links.begin ();
       link_tuple != links.end (); link_tuple++)
    {
      if (!(GetMainAddress (link_tuple->localIfaceAddr) == m_mainAddress
            && link_tuple->time >= now))
        {
          continue;
        }

      uint8_t link_type, nb_type = 0xff;

      // Establishes link type
      if (link_tuple->symTime >= now)
        {
          link_type = BATMAND_SYM_LINK;
        }
      else if (link_tuple->asymTime >= now)
        {
          link_type = BATMAND_ASYM_LINK;
        }
      else
        {
          link_type = BATMAND_LOST_LINK;
        }
      // Establishes neighbor type.
      if (m_state.FindMprAddress (GetMainAddress (link_tuple->neighborIfaceAddr)))
        {
          nb_type = BATMAND_MPR_NEIGH;
          NS_LOG_DEBUG ("I consider neighbor " << GetMainAddress (link_tuple->neighborIfaceAddr)
                                               << " to be MPR_NEIGH.");
        }
      else
        {
          bool ok = false;
          for (NeighborSet::const_iterator nb_tuple = m_state.GetNeighbors ().begin ();
               nb_tuple != m_state.GetNeighbors ().end ();
               nb_tuple++)
            {
              if (nb_tuple->neighborMainAddr == GetMainAddress (link_tuple->neighborIfaceAddr))
                {
                  if (nb_tuple->status == NeighborTuple::STATUS_SYM)
                    {
                      NS_LOG_DEBUG ("I consider neighbor " << GetMainAddress (link_tuple->neighborIfaceAddr)
                                                           << " to be SYM_NEIGH.");
                      nb_type = BATMAND_SYM_NEIGH;
                    }
                  else if (nb_tuple->status == NeighborTuple::STATUS_NOT_SYM)
                    {
                      nb_type = BATMAND_NOT_NEIGH;
                      NS_LOG_DEBUG ("I consider neighbor " << GetMainAddress (link_tuple->neighborIfaceAddr)
                                                           << " to be NOT_NEIGH.");
                    }
                  else
                    {
                      NS_FATAL_ERROR ("There is a neighbor tuple with an unknown status!\n");
                    }
                  ok = true;
                  break;
                }
            }
          if (!ok)
            {
              NS_LOG_WARN ("I don't know the neighbor " << GetMainAddress (link_tuple->neighborIfaceAddr) << "!!!");
              continue;
            }
        }

      olsr::MessageHeader::Hello::LinkMessage linkMessage;
      linkMessage.linkCode = (link_type & 0x03) | ((nb_type << 2) & 0x0f);
      linkMessage.neighborInterfaceAddresses.push_back
        (link_tuple->neighborIfaceAddr);

      std::vector<Ipv4Address> interfaces =
        m_state.FindNeighborInterfaces (link_tuple->neighborIfaceAddr);

      linkMessage.neighborInterfaceAddresses.insert
        (linkMessage.neighborInterfaceAddresses.end (),
        interfaces.begin (), interfaces.end ());

      linkMessages.push_back (linkMessage);
    }
  NS_LOG_DEBUG ("BATMAND HELLO message size: " << int (msg.GetSerializedSize ())
                                            << " (with " << int (linkMessages.size ()) << " link messages)");
  QueueMessage (msg, JITTER);
}



void
RoutingProtocol::SendHna ()
{

  olsr::MessageHeader msg;

  msg.SetVTime (BATMAND_HNA_HOLD_TIME);
  msg.SetOriginatorAddress (m_mainAddress);
  msg.SetTimeToLive (255);
  msg.SetHopCount (0);
  msg.SetMessageSequenceNumber (GetMessageSequenceNumber ());
  olsr::MessageHeader::Hna &hna = msg.GetHna ();

  std::vector<olsr::MessageHeader::Hna::Association> &associations = hna.associations;

  // Add all local HNA associations to the HNA message
  const Associations &localHnaAssociations = m_state.GetAssociations ();
  for (Associations::const_iterator it = localHnaAssociations.begin ();
       it != localHnaAssociations.end (); it++)
    {
      olsr::MessageHeader::Hna::Association assoc = { it->networkAddr, it->netmask};
      associations.push_back (assoc);
    }
  // If there is no HNA associations to send, return without queuing the message
  if (associations.size () == 0)
    {
      return;
    }

  // Else, queue the message to be sent later on
  QueueMessage (msg, JITTER);
}

void
RoutingProtocol::AddHostNetworkAssociation (Ipv4Address networkAddr, Ipv4Mask netmask)
{
  // Check if the (networkAddr, netmask) tuple already exist
  // in the list of local HNA associations
  const Associations &localHnaAssociations = m_state.GetAssociations ();
  for (Associations::const_iterator assocIterator = localHnaAssociations.begin ();
       assocIterator != localHnaAssociations.end (); assocIterator++)
    {
      Association const &localHnaAssoc = *assocIterator;
      if (localHnaAssoc.networkAddr == networkAddr && localHnaAssoc.netmask == netmask)
        {
          NS_LOG_INFO ("HNA association for network " << networkAddr << "/" << netmask << " already exists.");
          return;
        }
    }
  // If the tuple does not already exist, add it to the list of local HNA associations.
  NS_LOG_INFO ("Adding HNA association for network " << networkAddr << "/" << netmask << ".");
  m_state.InsertAssociation ( (Association) { networkAddr, netmask} );
}

void
RoutingProtocol::RemoveHostNetworkAssociation (Ipv4Address networkAddr, Ipv4Mask netmask)
{
  NS_LOG_INFO ("Removing HNA association for network " << networkAddr << "/" << netmask << ".");
  m_state.EraseAssociation ( (Association) { networkAddr, netmask} );
}

void
RoutingProtocol::SetRoutingTableAssociation (Ptr<Ipv4StaticRouting> routingTable)
{
  // If a routing table has already been associated, remove
  // corresponding entries from the list of local HNA associations
  if (m_routingTableAssociation != 0)
    {
      NS_LOG_INFO ("Removing HNA entries coming from the old routing table association.");
      for (uint32_t i = 0; i < m_routingTableAssociation->GetNRoutes (); i++)
        {
          Ipv4RoutingTableEntry route = m_routingTableAssociation->GetRoute (i);
          // If the outgoing interface for this route is a non-olsr interface
          if (UsesNonOlsrOutgoingInterface (route))
            {
              // remove the corresponding entry
              RemoveHostNetworkAssociation (route.GetDestNetwork (), route.GetDestNetworkMask ());
            }
        }
    }

  // Sets the routingTableAssociation to its new value
  m_routingTableAssociation = routingTable;

  // Iterate over entries of the associated routing table and
  // add the routes using non-olsr outgoing interfaces to the list
  // of local HNA associations
  NS_LOG_DEBUG ("Nb local associations before adding some entries from"
                " the associated routing table: " << m_state.GetAssociations ().size ());
  for (uint32_t i = 0; i < m_routingTableAssociation->GetNRoutes (); i++)
    {
      Ipv4RoutingTableEntry route = m_routingTableAssociation->GetRoute (i);
      Ipv4Address destNetworkAddress = route.GetDestNetwork ();
      Ipv4Mask destNetmask = route.GetDestNetworkMask ();

      // If the outgoing interface for this route is a non-olsr interface,
      if (UsesNonOlsrOutgoingInterface (route))
        {
          // Add this entry's network address and netmask to the list of local HNA entries
          AddHostNetworkAssociation (destNetworkAddress, destNetmask);
        }
    }
  NS_LOG_DEBUG ("Nb local associations after having added some entries from "
                "the associated routing table: " << m_state.GetAssociations ().size ());
}

bool
RoutingProtocol::UsesNonOlsrOutgoingInterface (const Ipv4RoutingTableEntry &route)
{
  std::set<uint32_t>::const_iterator ci = m_interfaceExclusions.find (route.GetInterface ());
  // The outgoing interface is a non-BATMAND interface if a match is found
  // before reaching the end of the list of excluded interfaces
  return ci != m_interfaceExclusions.end ();
}


uint16_t RoutingProtocol::GetPacketSequenceNumber ()
{
  m_packetSequenceNumber = (m_packetSequenceNumber + 1) % (BATMAND_MAX_SEQ_NUM + 1);
  return m_packetSequenceNumber;
}


void
RoutingProtocol::OgmTimerExpire ()
{
  SendOGM ();
  m_ogmTimer.Schedule (m_state.m_ogmInterval);
}


void
RoutingProtocol::Clear ()
{
  NS_LOG_FUNCTION_NOARGS ();
  m_table.clear ();
}

void
RoutingProtocol::RemoveEntry (Ipv4Address const &dest)
{
  m_table.erase (dest);
}

bool
RoutingProtocol::Lookup (Ipv4Address const &dest,
                         RoutingTableEntry &outEntry) const
{
  // Get the iterator at "dest" position
  std::map<Ipv4Address, RoutingTableEntry>::const_iterator it =
    m_table.find (dest);
  // If there is no route to "dest", return NULL
  if (it == m_table.end ())
    {
      return false;
    }
  outEntry = it->second;
  return true;
}

bool
RoutingProtocol::FindSendEntry (RoutingTableEntry const &entry,
                                RoutingTableEntry &outEntry) const
{
  outEntry = entry;
  while (outEntry.destAddr != outEntry.nextAddr)
    {
      if (not Lookup (outEntry.nextAddr, outEntry))
        {
          return false;
        }
    }
  return true;
}

Ptr<Ipv4Route>
RoutingProtocol::RouteOutput (Ptr<Packet> p, const Ipv4Header &header, Ptr<NetDevice> oif, Socket::SocketErrno &sockerr)
{
  NS_LOG_FUNCTION (this << " " << m_ipv4->GetObject<Node> ()->GetId () << " " << header.GetDestination () << " " << oif);
  Ptr<Ipv4Route> rtentry;
  RoutingTableEntry entry1, entry2;
  bool found = false;

  if (Lookup (header.GetDestination (), entry1) != 0)
    {
      bool foundSendEntry = FindSendEntry (entry1, entry2);
      if (!foundSendEntry)
        {
          NS_FATAL_ERROR ("FindSendEntry failure");
        }
      uint32_t interfaceIdx = entry2.interface;
      if (oif && m_ipv4->GetInterfaceForDevice (oif) != static_cast<int> (interfaceIdx))
        {
          // We do not attempt to perform a constrained routing search
          // if the caller specifies the oif; we just enforce that
          // that the found route matches the requested outbound interface
          NS_LOG_DEBUG ("Olsr node " << m_mainAddress
                                     << ": RouteOutput for dest=" << header.GetDestination ()
                                     << " Route interface " << interfaceIdx
                                     << " does not match requested output interface "
                                     << m_ipv4->GetInterfaceForDevice (oif));
          sockerr = Socket::ERROR_NOROUTETOHOST;
          return rtentry;
        }
      rtentry = Create<Ipv4Route> ();
      rtentry->SetDestination (header.GetDestination ());
      // the source address is the interface address that matches
      // the destination address (when multiple are present on the
      // outgoing interface, one is selected via scoping rules)
      NS_ASSERT (m_ipv4);
      uint32_t numOifAddresses = m_ipv4->GetNAddresses (interfaceIdx);
      NS_ASSERT (numOifAddresses > 0);
      Ipv4InterfaceAddress ifAddr;
      if (numOifAddresses == 1)
        {
          ifAddr = m_ipv4->GetAddress (interfaceIdx, 0);
        }
      else
        {
          /// \todo Implment IP aliasing and BATMAND
          NS_FATAL_ERROR ("XXX Not implemented yet:  IP aliasing and BATMAND");
        }
      rtentry->SetSource (ifAddr.GetLocal ());
      rtentry->SetGateway (entry2.nextAddr);
      rtentry->SetOutputDevice (m_ipv4->GetNetDevice (interfaceIdx));
      sockerr = Socket::ERROR_NOTERROR;
      NS_LOG_DEBUG ("Olsr node " << m_mainAddress
                                 << ": RouteOutput for dest=" << header.GetDestination ()
                                 << " --> nextHop=" << entry2.nextAddr
                                 << " interface=" << entry2.interface);
      NS_LOG_DEBUG ("Found route to " << rtentry->GetDestination () << " via nh " << rtentry->GetGateway () << " with source addr " << rtentry->GetSource () << " and output dev " << rtentry->GetOutputDevice ());
      found = true;
    }
  else
    {
      rtentry = m_hnaRoutingTable->RouteOutput (p, header, oif, sockerr);

      if (rtentry)
        {
          found = true;
          NS_LOG_DEBUG ("Found route to " << rtentry->GetDestination () << " via nh " << rtentry->GetGateway () << " with source addr " << rtentry->GetSource () << " and output dev " << rtentry->GetOutputDevice ());
        }
    }

  if (!found)
    {
      NS_LOG_DEBUG ("Olsr node " << m_mainAddress
                                 << ": RouteOutput for dest=" << header.GetDestination ()
                                 << " No route to host");
      sockerr = Socket::ERROR_NOROUTETOHOST;
    }
  return rtentry;
}

bool RoutingProtocol::RouteInput  (Ptr<const Packet> p,
                                   const Ipv4Header &header, Ptr<const NetDevice> idev,
                                   UnicastForwardCallback ucb, MulticastForwardCallback mcb,
                                   LocalDeliverCallback lcb, ErrorCallback ecb)
{
  NS_LOG_FUNCTION (this << " " << m_ipv4->GetObject<Node> ()->GetId () << " " << header.GetDestination ());

  Ipv4Address dst = header.GetDestination ();
  Ipv4Address origin = header.GetSource ();

  // Consume self-originated packets
  if (IsMyOwnAddress (origin) == true)
    {
      return true;
    }

  // Local delivery
  NS_ASSERT (m_ipv4->GetInterfaceForDevice (idev) >= 0);
  uint32_t iif = m_ipv4->GetInterfaceForDevice (idev);
  if (m_ipv4->IsDestinationAddress (dst, iif))
    {
      if (!lcb.IsNull ())
        {
          NS_LOG_LOGIC ("Local delivery to " << dst);
          lcb (p, header, iif);
          return true;
        }
      else
        {
          // The local delivery callback is null.  This may be a multicast
          // or broadcast packet, so return false so that another
          // multicast routing protocol can handle it.  It should be possible
          // to extend this to explicitly check whether it is a unicast
          // packet, and invoke the error callback if so
          return false;
        }
    }

  // Forwarding
  Ptr<Ipv4Route> rtentry;
  RoutingTableEntry entry1, entry2;
  if (Lookup (header.GetDestination (), entry1))
    {
      bool foundSendEntry = FindSendEntry (entry1, entry2);
      if (!foundSendEntry)
        {
          NS_FATAL_ERROR ("FindSendEntry failure");
        }
      rtentry = Create<Ipv4Route> ();
      rtentry->SetDestination (header.GetDestination ());
      uint32_t interfaceIdx = entry2.interface;
      // the source address is the interface address that matches
      // the destination address (when multiple are present on the
      // outgoing interface, one is selected via scoping rules)
      NS_ASSERT (m_ipv4);
      uint32_t numOifAddresses = m_ipv4->GetNAddresses (interfaceIdx);
      NS_ASSERT (numOifAddresses > 0);
      Ipv4InterfaceAddress ifAddr;
      if (numOifAddresses == 1)
        {
          ifAddr = m_ipv4->GetAddress (interfaceIdx, 0);
        }
      else
        {
          /// \todo Implment IP aliasing and BATMAND
          NS_FATAL_ERROR ("XXX Not implemented yet:  IP aliasing and BATMAND");
        }
      rtentry->SetSource (ifAddr.GetLocal ());
      rtentry->SetGateway (entry2.nextAddr);
      rtentry->SetOutputDevice (m_ipv4->GetNetDevice (interfaceIdx));

      NS_LOG_DEBUG ("Olsr node " << m_mainAddress
                                 << ": RouteInput for dest=" << header.GetDestination ()
                                 << " --> nextHop=" << entry2.nextAddr
                                 << " interface=" << entry2.interface);

      ucb (rtentry, p, header);
      return true;
    }
  else
    {
      if (m_hnaRoutingTable->RouteInput (p, header, idev, ucb, mcb, lcb, ecb))
        {
          return true;
        }
      else
        {

#ifdef NS3_LOG_ENABLE
          NS_LOG_DEBUG ("Olsr node " << m_mainAddress
                                     << ": RouteInput for dest=" << header.GetDestination ()
                                     << " --> NOT FOUND; ** Dumping routing table...");

          for (std::map<Ipv4Address, RoutingTableEntry>::const_iterator iter = m_table.begin ();
               iter != m_table.end (); iter++)
            {
              NS_LOG_DEBUG ("dest=" << iter->first << " --> next=" << iter->second.nextAddr
                                    << " via interface " << iter->second.interface);
            }

          NS_LOG_DEBUG ("** Routing table dump end.");
#endif // NS3_LOG_ENABLE

          return false;
        }
    }
}
void
RoutingProtocol::NotifyInterfaceUp (uint32_t i)
{
}
void
RoutingProtocol::NotifyInterfaceDown (uint32_t i)
{
}
void
RoutingProtocol::NotifyAddAddress (uint32_t interface, Ipv4InterfaceAddress address)
{
}
void
RoutingProtocol::NotifyRemoveAddress (uint32_t interface, Ipv4InterfaceAddress address)
{
}


void
RoutingProtocol::AddEntry (Ipv4Address const &dest,
                           Ipv4Address const &next,
                           uint32_t interface,
                           uint32_t distance)
{
  NS_LOG_FUNCTION (this << dest << next << interface << distance << m_mainAddress);

  NS_ASSERT (distance > 0);

  // Creates a new rt entry with specified values
  RoutingTableEntry &entry = m_table[dest];

  entry.destAddr = dest;
  entry.nextAddr = next;
  entry.interface = interface;
  entry.distance = distance;
}

void
RoutingProtocol::AddEntry (Ipv4Address const &dest,
                           Ipv4Address const &next,
                           Ipv4Address const &interfaceAddress,
                           uint32_t distance)
{
  NS_LOG_FUNCTION (this << dest << next << interfaceAddress << distance << m_mainAddress);

  NS_ASSERT (distance > 0);
  NS_ASSERT (m_ipv4);

  RoutingTableEntry entry;
  for (uint32_t i = 0; i < m_ipv4->GetNInterfaces (); i++)
    {
      for (uint32_t j = 0; j < m_ipv4->GetNAddresses (i); j++)
        {
          if (m_ipv4->GetAddress (i,j).GetLocal () == interfaceAddress)
            {
              AddEntry (dest, next, i, distance);
              return;
            }
        }
    }
  NS_ASSERT (false); // should not be reached
  AddEntry (dest, next, 0, distance);
}


std::vector<RoutingTableEntry>
RoutingProtocol::GetRoutingTableEntries () const
{
  std::vector<RoutingTableEntry> retval;
  for (std::map<Ipv4Address, RoutingTableEntry>::const_iterator iter = m_table.begin ();
       iter != m_table.end (); iter++)
    {
      retval.push_back (iter->second);
    }
  return retval;
}

int64_t
RoutingProtocol::AssignStreams (int64_t stream)
{
  NS_LOG_FUNCTION (this << stream);
  m_state.m_uniformRandomVariable->SetStream (stream);
  return 1;
}

bool
RoutingProtocol::IsMyOwnAddress (const Ipv4Address & a) const
{
  for (std::map<Ptr<Socket>, Ipv4InterfaceAddress>::const_iterator j =
         m_socketAddresses.begin (); j != m_socketAddresses.end (); ++j)
    {
      Ipv4InterfaceAddress iface = j->second;
      if (a == iface.GetLocal ())
        {
          return true;
        }
    }
  return false;
}

void
RoutingProtocol::Dump (void)
{
#ifdef NS3_LOG_ENABLE
  Time now = Simulator::Now ();
  NS_LOG_DEBUG ("Dumping for node with main address " << m_mainAddress);
  NS_LOG_DEBUG (" Neighbor set");
  for (NeighborSet::const_iterator iter = m_state.GetNeighbors ().begin ();
       iter != m_state.GetNeighbors ().end (); iter++)
    {
      NS_LOG_DEBUG ("  " << *iter);
    }
  NS_LOG_DEBUG (" Two-hop neighbor set");
  for (TwoHopNeighborSet::const_iterator iter = m_state.GetTwoHopNeighbors ().begin ();
       iter != m_state.GetTwoHopNeighbors ().end (); iter++)
    {
      if (now < iter->expirationTime)
        {
          NS_LOG_DEBUG ("  " << *iter);
        }
    }
  NS_LOG_DEBUG (" Routing table");
  for (std::map<Ipv4Address, RoutingTableEntry>::const_iterator iter = m_table.begin (); iter != m_table.end (); iter++)
    {
      NS_LOG_DEBUG ("  dest=" << iter->first << " --> next=" << iter->second.nextAddr << " via interface " << iter->second.interface);
    }
  NS_LOG_DEBUG ("");
#endif  //NS3_LOG_ENABLE
}

Ptr<const Ipv4StaticRouting>
RoutingProtocol::GetRoutingTableAssociation () const
{
  return m_hnaRoutingTable;
}

} // namespace olsr

}

