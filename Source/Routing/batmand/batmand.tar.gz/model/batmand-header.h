/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Rochester Institute of Technology
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Nelson Powell <nhp8080@rit.edu>
 *
 * NOTE:
 *
 * Code based on the OLSR module and modified for BATMAND-0.3.2
 * implementation.  OLSR was the predecessor for BATMAN and has many
 * similar features.  Plus, modifying the OLSR module reduces the
 * effort required to write a module from scratch.
 *
 * The BATMAN module is based on the IETF draft found at
 * https://tools.ietf.org/html/draft-openmesh-b-a-t-m-a-n-00 and the
 * BATMAN-0.3.2 code base downloadable from
 * https://www.open-mesh.org/projects/open-mesh/wiki/Download
 *
 *
 */

#ifndef BATMAND_HEADER_H
#define BATMAND_HEADER_H

#include <stdint.h>
#include <vector>
#include "ns3/header.h"
#include "ns3/ipv4-address.h"
#include "ns3/nstime.h"


namespace ns3 {
namespace batmand {

double EmfToSeconds (uint8_t emf);
uint8_t SecondsToEmf (double seconds);

#define COMPAT_VERSION 5

#define PORT 4305
#define GW_PORT 4306

/* Flags Fields */
#define UNIDIRECTIONAL  0x80
#define DIRECTLINK      0x40

#define ADDR_STR_LEN 16
#define TQ_MAX_VALUE 255

#define TTL 50                /* Time To Live of broadcast messages */
#define PURGE_TIMEOUT 200000u  /* purge originators after time in ms if no valid packet comes in -> TODO: check influence on TQ_LOCAL_WINDOW_SIZE */
#define TQ_LOCAL_WINDOW_SIZE 64     /* sliding packet range of received originator messages in squence numbers (should be a multiple of our word size) */
#define TQ_GLOBAL_WINDOW_SIZE 10
#define TQ_LOCAL_BIDRECT_SEND_MINIMUM 1
#define TQ_LOCAL_BIDRECT_RECV_MINIMUM 1
#define TQ_TOTAL_BIDRECT_LIMIT 1

#define MAX_AGGREGATION_MS 	100
#define MAX_AGGREGATION_BYTES	512

extern int local_win_size;

/**
 * \ingroup batmand
 *
 * The basic layout of any packet in BATMAND is as follows (omitting IP and
 * UDP headers):
  \verbatim
                     Originator Message (OGM) format.

    0                   1                   2                   3
    0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   |    Version    |U|D|           |      TTL      |    GWFlags    |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   |        Sequence Number        |             GW Port           |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   |                      Originator Address                       |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   |                   Previous Sender Address                     |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   |       TQ      |   HNA Length  |                               :
   :                                                               :
            (etc.)
  \endverbatim
  *
  * This is the fundamental BATMAND protocol packet format.
  */
class OGMHeader : public Header
{
public:
  OGMHeader ();
  virtual ~OGMHeader ();

  /**
   * Set the OGM packet version.
   * \param version The BATMAN protocol version employed.
   */
  void SetVersion (uint8_t version)
  {
    m_version = version;
  }

  /**
   * Get the OGM packet version.
   * \return The BATMAN protocol version employed.
   */
  uint8_t GetVersion () const
  {
    return m_version;
  }

  /**
   * Set the packet flags as a uint8_t (byte) field.
   * \param flags The packet flags as a byte.
   */
  void SetFlags (uint8_t flags)
  {
    m_flags = flags;
  }

  /**
   * Get the packet flags as a uint8_t (byte) field.
   * \return The packet flags as a byte.
   */
  uint8_t GetFlags () const
  {
    return m_flags;
  }

  /**
   * Set the DIRECT LINK flag bit in the flags field.
   * \param bool  Value of the DIRECT LINK bit.  TRUE by default.
   */
  void SetDirectLinkFlag ( bool val=true )
  {
    if ( val )
      m_flags |= DIRECTLINK;
    else
      m_flags &= ~DIRECTLINK;
  }

  /**
   * Check the packet flags for the DIRECT LINK bit being set.
   * \return TRUE if the direct link flag is asserted.
   */
  bool HasDirectLinkFlag () const
  {
    return m_flags & DIRECTLINK;
  }

  /**
   * Set the UNIDIRECTIONAL LINK flag bit in the flags field.
   * \param bool  Value of the UNIDIRECTIONAL LINK bit.  TRUE by default.
   */
  void SetUnidirectionalLinkFlag ( bool val=true )
  {
    if ( val )
      m_flags |= UNIDIRECTIONAL;
    else
      m_flags &= ~UNIDIRECTIONAL;
  }

  /**
   * Check the packet flags for the UNIDIRECTIONAL LINK bit being set.
   * \return TRUE if the unidirectional link flag is asserted.
   */
  bool HasUnidirectionalLinkFlag () const
  {
    return m_flags & UNIDIRECTIONAL;
  }

  /**
   * Set the packet TTL as a uint8_t (byte) field.
   * \param flags The packet TTL as a byte.
   */
  void SetTtl (uint8_t ttl)
  {
    m_ttl = ttl;
  }

  /**
   * Get the packet TTL as a uint8_t (byte) field.
   * \return The packet TTL as a byte.
   */
  uint8_t GetTtl () const
  {
    return m_ttl;
  }

  /**
   * Set the packet Gateway flags as a uint8_t (byte) field.
   * \param flags The packet Gateway flags as a byte.
   */
  void SetGWFlags (uint8_t flags)
  {
    m_gwflags = flags;
  }

  /**
   * Get the packet Gateway flags as a uint8_t (byte) field.
   * \return The packet Gateway flags as a byte.
   */
  uint8_t GetGWFlags () const
  {
    return m_gwflags;
  }

  /**
   * Set the packet sequence number.
   * \param seqnum The packet sequence number.
   */
  void SetPacketSequenceNumber (uint16_t seqnum)
  {
    m_packetSequenceNumber = seqnum;
  }

  /**
   * Get the packet sequence number.
   * \returns The packet sequence number.
   */
  uint16_t GetPacketSequenceNumber () const
  {
    return m_packetSequenceNumber;
  }

  /**
   * Set the advertised gateway port number.
   * \param port The advertised gateway port number.
   */
  void SetGatewayPortNumber (uint16_t port)
  {
    m_gatewayPortNumber = port;
  }

  /**
   * Get the advertised gateway port number.
   * \returns The advertised gateway port number.
   */
  uint16_t GetGatewayPortNumber () const
  {
    return m_gatewayPortNumber;
  }

  /**
   * Set the IPv4 address of the OGM origin station.
   * \param address The IPv4 address of the OGM origin station.
   */
  void SetOriginatorAddress (Ipv4Address address)
  {
     m_originatorAddress = address;
  }

  /**
   * Get the IPv4 address of the OGM origin station.
   * \returns The IPv4 address of the OGM origin station.
   */
  Ipv4Address GetOriginatorAddress () const
  {
    return m_originatorAddress;
  }

  /**
   * Set the IPv4 address of the forwarding station.
   * \param address The IPv4 address of the forwarding station.
   */
  void SetForwarderAddress (Ipv4Address address)
  {
     m_previousAddress = address;
  }

  /**
   * Get the IPv4 address of the forwarding station.
   * \returns The IPv4 address of the forwarding station.
   */
  Ipv4Address GetForwarderAddress () const
  {
    return m_previousAddress;
  }

  /**
   * Set the packet TQ value as a uint8_t (byte) field.
   * \param TQ  The packet TQ value as a byte.
   */
  void SetTQvalue (uint8_t TQ)
  {
    m_tq = TQ;
  }

  /**
   * Get the packet TQ value as a uint8_t (byte) field.
   * \return The packet TQ value as a byte.
   */
  uint8_t GetTQvalue () const
  {
    return m_tq;
  }

  /**
   * Set the packet HNA field length as a uint8_t (byte) field.
   *
   * NOTE: This could change by adding or removing HNA entries
   * form the structure.  This is a temporary place holder until
   * the HNA add/remove methods are added.
   *
   * \param flags The packet Gateway flags as a byte.
   */
  void SetHnaLength (uint8_t length)
  {
    m_hnaLength = length;
  }

  /**
   * Get the packet HNA field length as a uint8_t (byte) field.
   *
   * NOTE: This could change by adding or removing HNA entries
   * form the structure.  This is a temporary place holder until
   * the HNA add/remove methods are added.
   *
   * \return The packet Gateway flags as a byte.
   */
  uint8_t GetHnaLength () const
  {
    return m_hnaLength;
  }

  /**
   * \ingroup batmand
   * HNA (Host Network Association) Message Format
   *
   \verbatim
     0                   1                   2                   3
     0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
    +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
    |                         Network Address                       |
    +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
    |  Mask (CIDR)  |                                               |
    +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
    :                                                               :
   \endverbatim
   */
  struct Hna_s
  {
    /**
     * Association item structure.
     */
    struct Association
    {
      Ipv4Address address; //!< IPv4 Address.
//      Ipv4Mask mask;       //!< IPv4 netmask.
      uint8_t mask;        //!< IPv4 CIDR mask
    };

    std::vector<Association> associations; //!< Association container.

    /**
     * This method is used to print the content of a MID message.
     * \param os output stream
     */
    void Print (std::ostream &os) const;
    /**
     * Returns the expected size of the header.
     * \returns the expected size of the header.
     */
    uint32_t GetSerializedSize (void) const;
    /**
     * This method is used by Packet::AddHeader to
     * store a header into the byte buffer of a packet.
     *
     * \param start an iterator which points to where the header should
     *        be written.
     */
    void Serialize (Buffer::Iterator start) const;
    /**
     * This method is used by Packet::RemoveHeader to
     * re-create a header from the byte buffer of a packet.
     *
     * \param start an iterator which points to where the header should
     *        read from.
     * \param messageSize the message size.
     * \returns the number of bytes read.
     */
    uint32_t Deserialize (Buffer::Iterator start, uint32_t messageSize);
  };

private:
  uint8_t  m_version;               //!< BATMAN OGM versions
  uint8_t  m_flags;                 //!< OGM Flags field
  uint8_t  m_ttl;                   //!< OGM TTL count
  uint8_t  m_gwflags;               //!< OGM Gateway Flags
  uint16_t m_packetSequenceNumber;  //!< OGM Sequence Number
  uint16_t m_gatewayPortNumber;     //!< Gateway port supported by the BATMAN node
  Ipv4Address m_originatorAddress;  //!< IPv4 Address of the originator of the packet
  Ipv4Address m_previousAddress;    //!< IPv4 Address of the current sending station
  uint8_t  m_tq;                    //!< TQ value ??? original code provides no explanation
  uint8_t  m_hnaLength;             //!< Length of the succeeding HNA field
  Hna_s    m_hnaList;               //!< HNA addresses

public:
  /**
   * \brief Get the type ID.
   * \return The object TypeId.
   */
  static TypeId GetTypeId (void);
  virtual TypeId GetInstanceTypeId (void) const;
  virtual void Print (std::ostream &os) const;
  virtual uint32_t GetSerializedSize (void) const;
  virtual void Serialize (Buffer::Iterator start) const;
  virtual uint32_t Deserialize (Buffer::Iterator start);
};


static inline std::ostream& operator<< (std::ostream& os, const OGMHeader & packet)
{
  packet.Print (os);
  return os;
}

}
}  // namespace batmand, ns3

#endif /* OLSR_HEADER_H */

