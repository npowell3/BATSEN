/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */

/*
 * Copyright (c) 2016 Rochester Institute of Technology
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Nelson Powell <nhp8080@rit.edu>
 *
 * NOTE:
 *
 * Code based on the BATMAND module and modified for BATMAND-0.3.2
 * implementation.  BATMAND was the predecessor for BATMAN and has many
 * similar features.  Plus, modifying the BATMAND module reduces the
 * effort required to write a module from scratch.
 *
 * The BATMAN module is based on the IETF draft found at
 * https://tools.ietf.org/html/draft-openmesh-b-a-t-m-a-n-00 and the
 * BATMAN-0.3.2 code base downloadable from
 * https://www.open-mesh.org/projects/open-mesh/wiki/Download
 *
 *
 */

///
/// \brief Implementation of BATMAND agent and related classes.
///
/// This is the main file of this software because %BATMAND's behavior is
/// implemented here.
///

#include "batmand-structures.h"
#include "ns3/ipv4-address.h"
#include "ns3/log.h"
#include "ns3/names.h"

#include <arpa/inet.h>

namespace ns3 {
  
NS_LOG_COMPONENT_DEFINE ("BatmanStructs");

namespace batmand {

static const unsigned int BitCount[16] {
    0,    // 0000
    1,    // 0001
    1,    // 0010
    2,    // 0011
    1,    // 0100
    2,    // 0101
    2,    // 0110
    3,    // 0111
    1,    // 1000
    2,    // 1001
    2,    // 1010
    3,    // 1011
    2,    // 1100
    3,    // 1101
    3,    // 1110
    4     // 1111
};

void BatmanData::AddBatmanIface(batman_if iface) {
 m_batmanif.push_back (iface);
}

struct batman_if *BatmanData::FindBatmanIf( Ipv4Address addr ) {
   int size = m_batmanif.size();
   batman_if *iface = NULL;

   for ( int i = 0; i < size; ++i ) {
      if ( m_batmanif[i].addr == addr ) {
         iface = &( m_batmanif[i] );
         break;
      }
   }

   return iface;
}

struct orig_node *BatmanData::GetOrCreateOrigNode( Ipv4Address addr ) {
   struct orig_node *orig_node = FindOrigNode( addr );

   if ( NULL == orig_node ) {
      struct orig_node tmp;
      memset(&tmp, 0, sizeof(struct orig_node));

      tmp.orig = addr;
      tmp.router = NULL;
      tmp.batman_if = NULL;

      NS_LOG_DEBUG( "Creating new originator: " << addr );

      m_OriginSet.push_back( tmp );
      orig_node = FindOrigNode( addr );

      NS_ASSERT( NULL == orig_node );
   }

   return orig_node;
}

struct orig_node *BatmanData::FindOrigNode( Ipv4Address addr ) {
   int size = m_OriginSet.size();
   orig_node *originnode = NULL;

   for ( int i = 0; i < size; ++i ) {
      if ( m_OriginSet[i].orig == addr ) {
         originnode = &( m_OriginSet[i] );
         break;
      }
   }

   return originnode;
}

struct neigh_node *BatmanData::FindNeighborNode( struct orig_node *orig_node, Ipv4Address addr ) {
   int size = orig_node->neigh_list.size();
   struct neigh_node *retval = NULL;

   for ( int i = 0; i < size; ++i ) {
      if ( orig_node->neigh_list[i].addr == addr ) {
         retval = &( orig_node->neigh_list[i] );
         break;
      }
   }

   return retval;
}

/* turn corresponding bit on, so we can remember that we got the packet */
void BatmanData::MarkSequenceBit( uint64_t &seq_bits, int32_t n ) {
  /* if too old, just drop it, otherwise mark it */
  if ( !( n < 0 || n >= local_win_size) ) {
    NS_LOG_DEBUG( "\tmark bit " << n );
    seq_bits |= (1 << n);  /* turn the position on */
  }
}


int BatmanData::Uint64BitCount( uint64_t &seq_bits ) {

  int i, hamming = 0;
  uint8_t *word = (uint8_t *)&seq_bits;

  for (i = 0; i < 8; i++) {
    uint8_t high = ( (*word) & 0xF0 ) >> 4;
    uint8_t low  = ( (*word) & 0x0F );

    hamming += BitCount[high] + BitCount[low];
    ++word;
  }

  return(hamming);
}


bool BatmanData::CountRealPackets( OGMHeader &pkt, Ipv4Address neigh, uint8_t ifnum )
{
  struct orig_node *orig_node;
  struct neigh_node *tmpNeighNode;
  unsigned int i = 0;
  bool is_duplicate = false;
  bool is_new_seqno = false;
  int32_t pktSeqNumber = pkt.GetPacketSequenceNumber();
  int32_t lastSeqNumber = orig_node->last_real_seqno;

  orig_node = GetOrCreateOrigNode( pkt.GetForwarderAddress() );

  NS_LOG_DEBUG("count_real_packets: orig = " << orig_node->orig << ", neigh = "<< neigh <<", seq = " << pktSeqNumber << ", last seq = " << orig_node->last_real_seqno  );

  // Traverse the neighbor list for the given origin node
  for ( i = 0; i < orig_node->neigh_list.size(); ++i ) {
    tmpNeighNode = &(orig_node->neigh_list[i]);

    if ( !is_duplicate )
      is_duplicate = GetHistoricalSequenceBitStatus( tmpNeighNode->real_bits, lastSeqNumber, pktSeqNumber );

    if ( ( tmpNeighNode->addr == neigh ) && ( tmpNeighNode->ifnum == ifnum ) ) {
      bit_get_packet( tmpNeighNode->real_bits, pktSeqNumber - lastSeqNumber, 1 );
      NS_LOG_DEBUG("count_real_packets (yes): neigh = " << neigh << ", is_new = " << (is_new_seqno ? "YES" : "NO") << ", seq = " << pktSeqNumber << ", last seq = " << lastSeqNumber );
    }
    else {
      bit_get_packet( tmpNeighNode->real_bits, pktSeqNumber - lastSeqNumber, 0 );
      NS_LOG_DEBUG("count_real_packets (no): neigh = " << neigh << ", is_new = " << (is_new_seqno ? "YES" : "NO") << ", seq = " << pktSeqNumber << ", last seq = " << lastSeqNumber );
    }

    tmpNeighNode->real_packet_count = Uint64BitCount( tmpNeighNode->real_bits );
  }

  if ( !is_duplicate ) {
    NS_LOG_DEBUG("updating last_seqno: old " << lastSeqNumber << ", new " << pktSeqNumber );
    orig_node->last_real_seqno = pktSeqNumber;
  }

  return is_duplicate;
}


bool BatmanData::GetHistoricalSequenceBitStatus( uint64_t &seq_bits, int32_t &last_seqno, int32_t &curr_seqno ) {
  bool retval = false;
  int16_t diff;

  diff = last_seqno - curr_seqno;

  if ( !((diff < 0) || (diff >= local_win_size)) )
    retval = seq_bits & (1 << diff);

  return retval;
}


bool BatmanData::bit_get_packet( uint64_t &seq_bits, int16_t seq_num_diff, int8_t set_mark ) {
  bool isnew = true;

  /* We already got a sequence number higher than this one, so we
   * just mark it. This should wrap around the integer just fine.
   */
  if ((seq_num_diff < 0) && (seq_num_diff >= -local_win_size)) {
    if ( set_mark )
      MarkSequenceBit( seq_bits, -seq_num_diff );
    isnew = false;
  }
  else if ( (seq_num_diff > local_win_size) || (seq_num_diff < -local_win_size) ) {
    /* it seems we missed a lot of packets or the other host restarted */
    if (seq_num_diff > local_win_size)
      NS_LOG_DEBUG("It seems we missed a lot of packets (" << (seq_num_diff - 1) <<") !");

    if (-seq_num_diff > local_win_size)
      NS_LOG_DEBUG("Other host probably restarted !");

    seq_bits = 0;

    /* we only have the latest packet */
    if ( set_mark )
      seq_bits = 1;
  }
  else {
    bit_shift(seq_bits, seq_num_diff);

    if ( set_mark )
      MarkSequenceBit(seq_bits, 0);
  }

  return isnew;
}


void BatmanData::bit_shift( uint64_t seq_bits, int32_t n ) {
  if( n > 0 ) {
     NS_LOG_DEBUG( "bit_shift\n\toriginal seq bits: " << seq_bits );
     seq_bits <<= n;
     NS_LOG_DEBUG( "\tFinal seq bits: " << seq_bits );
  }
}


struct neigh_node *BatmanData::CreateNeighbor( struct orig_node *orig_node,
                                               struct orig_node *orig_neigh_node,
                                               Ipv4Address neigh,
                                               uint8_t ifnum ) {
   struct neigh_node neigh_node;

   NS_LOG_DEBUG( "Creating new last-hop neighbor of originator\n" );

   memset( &neigh_node, 0, sizeof(struct neigh_node) );

   neigh_node.addr = neigh;
   neigh_node.orig_node = orig_neigh_node;
   neigh_node.ifnum = ifnum;

//   neigh_node.tq_recv = debugMalloc(sizeof(uint16_t) * global_win_size, 406);
//   memset(neigh_node.tq_recv, 0, sizeof(uint16_t) * global_win_size);
//
//   neigh_node->real_bits = debugMalloc(sizeof(TYPE_OF_WORD) * num_words, 407);
//   memset(neigh_node.real_bits, 0, sizeof(TYPE_OF_WORD) * num_words);

   orig_node->neigh_list.push_back(neigh_node);

   return FindNeighborNode( orig_node, neigh );
}


void BatmanData::ScheduleForwardPacket(struct orig_node *orig_node, struct bat_packet *in,
                                       Ipv4Address neigh, uint8_t directlink, int16_t hna_buff_len,
                                       struct batman_if *if_incoming, ns3::Time curr_time)
{
  struct forw_node *forw_node_new = NULL, *forw_node_aggregate = NULL, *forw_node_pos = NULL;
  int prev_list_head = -1;
//  struct list_head *list_pos = forw_list.next, *prev_list_head = (struct list_head *)&forw_list;
  struct bat_packet *bat_packet;
  uint8_t tq_avg = 0;
  ns3::Time send_time;

  NS_LOG_DEBUG( "schedule_forward_packet():  \n" );
  if (in->ttl <= 1) {
    NS_LOG_DEBUG( "ttl exceeded \n" );
    return;
  }

  if (m_aggregationEnabled)
    send_time = curr_time + ns3::Time(MAX_AGGREGATION_MS) - (JITTER/2) + JITTER;
  else
    send_time = curr_time + (JITTER/2);


  /* find position for the packet in the forward queue */
  for (int i = 0; i < m_forwardingSet.size(); ++i ) {

    forw_node_pos = &(m_forwardingSet[i]);

    if (m_aggregationEnabled) {

      /* don't save aggregation position if aggregation is disabled */
      forw_node_aggregate = forw_node_pos;

      /**
       * we can aggregate the current packet to this packet if:
       * - the send time is within our MAX_AGGREGATION_MS time
       * - the resulting packet wont be bigger than MAX_AGGREGATION_BYTES
       */
      if (((forw_node_pos->send_time - send_time) < 0) &&
        (forw_node_pos->pack_buff_len + sizeof(struct bat_packet) + hna_buff_len <= MAX_AGGREGATION_BYTES)) {

        bat_packet = (struct bat_packet *)forw_node_pos->pack_buff;

        /**
         * check aggregation compatibility
         * -> direct link packets are broadcasted on their interface only
         * -> aggregate packet if the current packet is a "global" packet
         *    as well as the base packet
         */
        /* packets without direct link flag and high TTL are flooded through the net  */
        if ((!directlink) && (!(bat_packet->flags & DIRECTLINK)) && (bat_packet->ttl != 1) &&
        /* own packets originating non-primary interfaces leave only that interface */
            ((!forw_node_pos->own) || (forw_node_pos->if_incoming->if_num == 0)))
          break;

        /* if the incoming packet is sent via this one interface only - we still can aggregate */
        if ((directlink) && (in->ttl == 2) && (forw_node_pos->if_incoming == if_incoming))
          break;

      }

      /* could not find packet to aggregate with */
      forw_node_aggregate = NULL;
    }

    if ((forw_node_pos->send_time - send_time) > 0)
      break;

    prev_list_head = i;
    forw_node_pos = NULL;
  }

  /* nothing to aggregate with - either aggregation disabled or no suitable aggregation packet found */
  if (forw_node_aggregate == NULL) {
    ForwardingList::iterator itr = m_forwardingSet.begin();
    struct forw_node forw_node_new;
    forw_node_new.pack_buff = new unsigned char[MAX_AGGREGATION_BYTES];
    
    // Resize the m_forwardingSet and put this packet up front ??
    itr = m_forwardingSet.insert ( itr, forw_node_new );
    itr = m_forwardingSet.begin();

    itr->pack_buff_len = sizeof(struct bat_packet) + hna_buff_len;
    memcpy(itr->pack_buff, in, itr->pack_buff_len);

    bat_packet = (struct bat_packet *)itr->pack_buff;

    itr->own = 0;
    itr->if_incoming = if_incoming;
    itr->num_packets = 0;
    itr->direct_link_flags = 0;

    itr->send_time = send_time;
  } 
  else {
    memcpy(forw_node_aggregate->pack_buff + forw_node_aggregate->pack_buff_len, in, sizeof(struct bat_packet) + hna_buff_len);
    bat_packet = (struct bat_packet *)(forw_node_aggregate->pack_buff + forw_node_aggregate->pack_buff_len);
    forw_node_aggregate->pack_buff_len += sizeof(struct bat_packet) + hna_buff_len;

    forw_node_aggregate->num_packets++;

    forw_node_new = forw_node_aggregate;
  }

  /* save packet direct link flag status */
  if (directlink)
    forw_node_new->direct_link_flags = forw_node_new->direct_link_flags | (1 << forw_node_new->num_packets);

  bat_packet->ttl--;
  bat_packet->prev_sender = neigh.Get();

  /* rebroadcast tq of our best ranking neighbor to ensure the rebroadcast of our best tq value */
  if ((orig_node->router != NULL) && (orig_node->router->tq_avg != 0)) {

    /* rebroadcast ogm of best ranking neighbor as is */
    if (orig_node->router->addr != neigh) {

      bat_packet->tq = orig_node->router->tq_avg;
      bat_packet->ttl = orig_node->router->last_ttl - 1;

    }

    tq_avg = orig_node->router->tq_avg;

  }

  /* apply hop penalty */
  bat_packet->tq = (bat_packet->tq * (TQ_MAX_VALUE - m_hopPenalty)) / (TQ_MAX_VALUE);

  NS_LOG_DEBUG( "forwarding: tq_orig: " << in->tq << ", tq_avg: " << tq_avg << ", tq_forw: " << bat_packet->tq <<
                ", ttl_orig: " << (in->ttl - 1) << ", ttl_forw: " << bat_packet->ttl );

  /* change sequence number to network order */
  bat_packet->seqno = htons(bat_packet->seqno);

  if (directlink)
    bat_packet->flags |= DIRECTLINK;
  else
    bat_packet->flags &= ~DIRECTLINK;


  /* if the packet was not aggregated */
  if (forw_node_aggregate == NULL) {
    ForwardingList::iterator itr = m_forwardingSet.begin();
    
    /* if the packet should go somewhere in the queue */
    if (forw_node_pos != NULL)
      list_add_before(prev_list_head, list_pos, &forw_node_new->list);
    /* if the packet is the last packet in the queue */
    else
      list_add_tail(&forw_node_new->list, &forw_list);
  }
}


}
} // namespace batmand, ns3
